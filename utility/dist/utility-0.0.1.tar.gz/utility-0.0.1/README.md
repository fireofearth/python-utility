
Basic Python and Scipy utility methods.


Build using

```
python setup.py sdist bdist_wheel
```

Install using

```
pip install <path to wheel>.whl
```
