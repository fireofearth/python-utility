
Utility methods for the CARLA simulator's Python API.

```
python setup.py sdist bdist_wheel
```
